"""
Session create / edit form.
"""

from typing import Callable
from nicegui import ui

from src.models.session import Session
from src.models.exercise import get_all as get_all_exercises, get_by_id as get_exercise
from src.models import session as session_model
from src.utils.formatting import today_iso
from src.ui.components import (
    page_title,
    section_title,
    form_card,
    action_row,
    input_field,
    number_field,
    select_field,
    textarea_field,
    btn_primary,
    btn_ghost,
    btn_danger,
)

_ENERGY_OPTIONS = {1: "1 — Empty", 2: "2 — Low", 3: "3 — Moderate", 4: "4 — Good", 5: "5 — Peak"}
_FEELING_OPTIONS = ["Poor", "Below average", "Average", "Good", "Excellent"]


def render(session_id: str | None, navigate: Callable) -> None:
    existing = session_model.get_by_id(session_id) if session_id else None

    # Mutable state for the two exercise lists
    warmup_ids = list(existing.warmup if existing else [])
    exercise_ids = list(existing.exercises if existing else [])

    # Build exercise options map  label → id
    all_ex = get_all_exercises()
    ex_options = {e.display_name(): e._id for e in all_ex}
    ex_labels = list(ex_options.keys())

    with ui.column().classes("page-content"):
        page_title("Edit Session" if existing else "New Session")

        # ── Basic info ────────────────────────────────────────────────────
        section_title("Session info")
        with form_card():
            date_in = input_field(
                "Date (YYYY-MM-DD)", value=existing.date if existing else today_iso()
            )
            ui.element("div").style("height:0.5rem")
            energy_in = select_field(
                "Energy Level",
                options=_ENERGY_OPTIONS,
                value=existing.energy_level if existing else 3,
            )
            ui.element("div").style("height:0.5rem")
            feeling_in = select_field(
                "Feeling / Progress",
                options=_FEELING_OPTIONS,
                value=existing.feeling if existing else "Average",
            )
            ui.element("div").style("height:0.5rem")
            notes_in = textarea_field("Notes", value=existing.notes if existing else "")

        ui.element("div").style("height:1.25rem")

        # ── Warmup ────────────────────────────────────────────────────────
        section_title("Warmup")
        warmup_container = ui.column().style("width:100%;max-width:520px;gap:0")

        def refresh_warmup() -> None:
            warmup_container.clear()
            with warmup_container:
                for i, eid in enumerate(warmup_ids):
                    ex = get_exercise(eid)
                    label = ex.display_name() if ex else eid
                    with ui.row().style("align-items:center;gap:8px;margin-bottom:4px"):
                        ui.label(label).style("color:#777;font-size:0.78rem;flex:1")
                        btn_danger(
                            "×",
                            on_click=lambda idx=i: _remove_from(warmup_ids, idx, refresh_warmup),
                        )

        refresh_warmup()

        if ex_labels:
            with ui.row().style("gap:8px;margin-top:0.5rem;max-width:520px;align-items:center"):
                warmup_sel = select_field("Add to warmup", options=ex_labels).style(
                    "flex:1;width:auto"
                )
                btn_ghost(
                    "Add",
                    on_click=lambda: _add_to(warmup_ids, ex_options, warmup_sel, refresh_warmup),
                )

        ui.element("div").style("height:1.25rem")

        # ── Exercises ─────────────────────────────────────────────────────
        section_title("Exercises")
        ex_container = ui.column().style("width:100%;max-width:520px;gap:0")

        def refresh_exercises() -> None:
            ex_container.clear()
            with ex_container:
                for i, eid in enumerate(exercise_ids):
                    ex = get_exercise(eid)
                    label = ex.display_name() if ex else eid
                    with ui.row().style("align-items:center;gap:8px;margin-bottom:4px"):
                        ui.label(label).style("color:#e8e4dc;font-size:0.82rem;flex:1")
                        btn_danger(
                            "×",
                            on_click=lambda idx=i: _remove_from(
                                exercise_ids, idx, refresh_exercises
                            ),
                        )

        refresh_exercises()

        if ex_labels:
            with ui.row().style("gap:8px;margin-top:0.5rem;max-width:520px;align-items:center"):
                ex_sel = select_field("Add exercise", options=ex_labels).style("flex:1;width:auto")
                btn_ghost(
                    "Add",
                    on_click=lambda: _add_to(exercise_ids, ex_options, ex_sel, refresh_exercises),
                )

        # ── Save ──────────────────────────────────────────────────────────
        with action_row():
            btn_primary(
                "Save Session",
                on_click=lambda: _save(
                    session_id,
                    date_in,
                    energy_in,
                    feeling_in,
                    notes_in,
                    warmup_ids,
                    exercise_ids,
                    navigate,
                ),
            )
            btn_ghost("Cancel", on_click=lambda: navigate("sessions"))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _add_to(id_list: list, options: dict, selector: ui.select, refresh: Callable) -> None:
    if selector.value and selector.value in options:
        id_list.append(options[selector.value])
        refresh()


def _remove_from(id_list: list, index: int, refresh: Callable) -> None:
    id_list.pop(index)
    refresh()


def _save(
    session_id,
    date_in,
    energy_in,
    feeling_in,
    notes_in,
    warmup_ids,
    exercise_ids,
    navigate: Callable,
) -> None:
    if not date_in.value.strip():
        ui.notify("Date is required", color="negative")
        return

    s = Session(
        date=date_in.value.strip(),
        energy_level=energy_in.value,
        feeling=feeling_in.value,
        notes=notes_in.value.strip(),
        warmup=list(warmup_ids),
        exercises=list(exercise_ids),
    )

    if session_id:
        session_model.update(session_id, s)
        ui.notify("Session updated", color="positive")
    else:
        session_model.create(s)
        ui.notify("Session saved", color="positive")

    navigate("sessions")

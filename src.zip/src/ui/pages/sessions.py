"""
Sessions list page.
"""

from collections.abc import Callable

from nicegui import ui

from src.models import session as session_model
from src.ui.components import btn_ghost
from src.ui.components import btn_primary
from src.ui.components import energy_badge
from src.ui.components import page_header_row
from src.ui.components import page_title
from src.ui.components import section_title
from src.utils.formatting import pluralize
from src.utils.formatting import scale_label

_ENERGY_LABELS = {1: "Empty", 2: "Low", 3: "Moderate", 4: "Good", 5: "Peak"}
_ENERGY_COLORS = {1: "#c0392b", 2: "#e67e22", 3: "#f1c40f", 4: "#2ecc71", 5: "#c8f566"}


def render(navigate: Callable) -> None:
    sessions = session_model.get_all()

    with ui.column().classes("page-content"):
        with page_header_row():
            page_title("Sessions")
            btn_primary("+ New Session", on_click=lambda: navigate("session_form"))

        if not sessions:
            ui.label("No sessions yet. Log your first workout.").style(
                "color:#555;font-size:0.82rem"
            )
            return

        section_title(pluralize(len(sessions), "session") + " logged")

        for s in sessions:
            lvl = s.energy_level
            color = _ENERGY_COLORS.get(lvl, "#888")
            n_ex = len(s.workout)
            sid = s._id

            with ui.row().classes("card").style("align-items:center;justify-content:space-between"):
                with ui.row().style("align-items:center;gap:1rem;flex:1"):
                    energy_badge(lvl)
                    with ui.column().style("gap:3px"):
                        ui.label(s.date).classes("card-title")
                        ui.label(
                            f"{pluralize(n_ex, 'exercise')} · "
                            f"{s.progress} · "
                            f"{scale_label(lvl, _ENERGY_LABELS)} energy"
                        ).classes("meta-row")
                btn_ghost("View →", on_click=lambda sid_=sid: navigate("session_detail", sid_))

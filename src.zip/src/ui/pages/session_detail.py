"""
Session detail page — read-only view of a single session.
"""

from collections.abc import Callable

from nicegui import ui

from src.models import exercise as exercise_model
from src.models import session as session_model
from src.ui.components import btn_danger
from src.ui.components import btn_ghost
from src.ui.components import divider
from src.ui.components import energy_badge
from src.ui.components import page_title
from src.ui.components import section_title
from src.ui.components import tag
from src.utils.formatting import pluralize
from src.utils.formatting import scale_label

_ENERGY_LABELS = {1: "Empty", 2: "Low", 3: "Moderate", 4: "Good", 5: "Peak"}
_ENERGY_COLORS = {1: "#c0392b", 2: "#e67e22", 3: "#f1c40f", 4: "#2ecc71", 5: "#c8f566"}


def render(session_id: str, navigate: Callable) -> None:
    s = session_model.get_by_id(session_id)
    if not s:
        ui.label("Session not found.").style("color:#555")
        return

    with ui.column().classes("page-content"):
        btn_ghost("← Back", on_click=lambda: navigate("sessions"))

        ui.element("div").style("height:0.75rem")
        page_title(f"Session — {s.date}")

        # Meta strip
        lvl = s.energy_level
        with ui.row().style("gap:1.2rem;align-items:center;margin-bottom:1.5rem;flex-wrap:wrap"):
            with ui.row().style("align-items:center;gap:6px"):
                energy_badge(lvl)
                ui.label(f"{scale_label(lvl, _ENERGY_LABELS)} energy").style(
                    f"color:{_ENERGY_COLORS.get(lvl, '#888')};font-size:0.78rem"
                )
            ui.label(f"Feeling: {s.progress}").style("color:#666;font-size:0.78rem")
            if s.notes:
                ui.label(s.notes).style("color:#555;font-size:0.78rem;font-style:italic")

        divider()

        # Warmup
        if s.warmup:
            section_title(f"Warmup — {pluralize(len(s.warmup), 'exercise')}")
            for ex_id in s.warmup:
                ex = exercise_model.get_by_id(ex_id)
                if ex:
                    _exercise_row(ex, dim=True)
            divider()

        # Main exercises
        section_title(f"Exercises — {pluralize(len(s.exercises), 'movement')}")
        if s.exercises:
            for ex_id in s.exercises:
                ex = exercise_model.get_by_id(ex_id)
                if ex:
                    _exercise_row(ex)
        else:
            ui.label("No exercises in this session.").style("color:#555;font-size:0.8rem")

        divider()

        sid = s._id
        with ui.row().style("gap:0.75rem"):
            btn_ghost("Edit", on_click=lambda: navigate("session_form", sid))
            btn_danger("Delete", on_click=lambda: _delete(sid, navigate))


def _exercise_row(ex: exercise_model.Exercise, dim: bool = False) -> None:
    color = "#555" if dim else "#e8e4dc"
    with ui.row().classes("card").style(f"align-items:center;{'opacity:0.55;' if dim else ''}"):
        with ui.column().style("gap:3px"):
            with ui.row().style("align-items:center;gap:8px"):
                ui.label(ex.name).style(
                    f"font-family:'Syne',sans-serif;font-weight:600;font-size:0.9rem;color:{color}"
                )
                if ex.variant:
                    tag(ex.variant, accent=True)
            ui.label(f"{ex.sets} sets · {ex.reps} reps · {ex.rest_seconds}s rest").classes(
                "meta-row"
            )


def _delete(session_id: str, navigate: Callable) -> None:
    session_model.delete(session_id)
    ui.notify("Session deleted")
    navigate("sessions")

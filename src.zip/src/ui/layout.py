"""
Top-level layout: header, nav, main content area, and page router.
"""

from collections.abc import Callable

from nicegui import ui

from src.ui.styles import STYLES

# ---------------------------------------------------------------------------
# Navigation state
# ---------------------------------------------------------------------------

_state: dict[str, str | None] = {
    "page": "sessions",  # current page key
    "param": None,  # optional id / context for the page
}

_nav_buttons: dict[str, ui.button] = {}
_main_container: dict[str, ui.column] = {}

# Map page keys → which nav tab they belong to
_NAV_OWNERSHIP: dict[str, str] = {
    "sessions": "sessions",
    "session_detail": "sessions",
    "session_form": "sessions",
    "exercises": "exercises",
    "exercise_form": "exercises",
}


def navigate(page: str, param: str | None = None) -> None:
    """Switch to a page, optionally with a record id."""
    _state["page"] = page
    _state["param"] = param
    _rebuild_main()
    _update_nav()


def _update_nav() -> None:
    active_tab = _NAV_OWNERSHIP.get(_state["page"])
    for tab, btn in _nav_buttons.items():
        if tab == active_tab:
            btn.classes(add="active")
        else:
            btn.classes(remove="active")


def _rebuild_main() -> None:
    """Clear the main container and render the current page."""
    container = _main_container.get("el")
    if container is None:
        return
    container.clear()

    # Lazy imports avoid circular imports at module load time
    from src.ui.pages.exercise_form import render as exercise_form_page
    from src.ui.pages.exercises import render as exercises_page
    from src.ui.pages.session_detail import render as session_detail_page
    from src.ui.pages.session_form import render as session_form_page
    from src.ui.pages.sessions import render as sessions_page

    dispatch: dict[str, Callable] = {
        "sessions": lambda: sessions_page(navigate),
        "session_detail": lambda: session_detail_page(_state["param"], navigate),
        "session_form": lambda: session_form_page(_state["param"], navigate),
        "exercises": lambda: exercises_page(navigate),
        "exercise_form": lambda: exercise_form_page(_state["param"], navigate),
    }

    renderer = dispatch.get(_state["page"])
    with container:
        if renderer:
            renderer()
        else:
            ui.label(f"Unknown page: {_state['page']}").style("color:#555")


# ---------------------------------------------------------------------------
# Build
# ---------------------------------------------------------------------------


def build_layout() -> None:
    ui.add_head_html(f"<style>{STYLES}</style>")
    ui.query("body").style("background:#0f0f0f;margin:0")

    # Header
    with ui.row().classes("app-header").style("width:100%"):
        ui.label("LAFAY").classes("app-title")

        for label, page in [("Sessions", "sessions"), ("Exercises", "exercises")]:
            btn = ui.button(label, on_click=lambda p=page: navigate(p)).classes("nav-btn")
            _nav_buttons[page] = btn

    # Main scrollable area
    _main_container["el"] = ui.column().style("width:100%;min-height:calc(100vh - 56px)")
    navigate("sessions")
